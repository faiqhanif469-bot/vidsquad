
================================================================================
CAPCUT PROJECT - The_Ocean's_Majesty_and_Importance
================================================================================

📂 FOLDER STRUCTURE:
   The_Ocean's_Majesty_and_Importance_CapCut/
   ├── draft_content.json          ← CapCut project file
   ├── Media/
   │   ├── Clips/                  ← Video clips
   │   └── Images/                 ← AI-generated images
   ├── scene_order.json            ← Scene metadata
   └── README.txt                  ← This file

================================================================================
HOW TO IMPORT INTO CAPCUT:
================================================================================

METHOD 1: Import Project (Desktop)
-----------------------------------
1. Open CapCut Desktop App
2. Click "Import Project"
3. Navigate to this folder
4. Select "draft_content.json"
5. Click "Open"
6. All media will be loaded on timeline

METHOD 2: Drag & Drop (Desktop)
--------------------------------
1. Open CapCut Desktop App
2. Create New Project
3. Drag entire "Media" folder into CapCut
4. Arrange clips on timeline by scene number

METHOD 3: Mobile (CapCut App)
------------------------------
1. Transfer this folder to your phone
2. Open CapCut mobile app
3. Tap "New Project"
4. Select all files from Media/Clips and Media/Images
5. Arrange by scene number

================================================================================
EDITING TIPS:
================================================================================

✓ All clips are pre-organized by scene number
✓ Video clips are in Media/Clips/
✓ AI-generated images are in Media/Images/
✓ Default duration for images: 5 seconds
✓ Recommended: Add transitions (swipe, fade, zoom)
✓ Recommended: Add background music from CapCut library
✓ Recommended: Add text/captions for narration
✓ Recommended: Apply filters for consistent look

================================================================================
CAPCUT FEATURES TO USE:
================================================================================

🎨 Effects:
   - Transitions between scenes
   - Filters for mood/tone
   - Speed adjustments

🎵 Audio:
   - Background music from library
   - Sound effects
   - Voiceover recording

📝 Text:
   - Captions/subtitles
   - Title cards
   - Lower thirds

✨ Advanced:
   - Keyframe animations
   - Chroma key (green screen)
   - Picture-in-picture

================================================================================
EXPORT SETTINGS (Recommended):
================================================================================

Resolution: 1080p (1920x1080)
Frame Rate: 30 fps
Quality: High
Format: MP4

For Social Media:
- YouTube: 1080p, 16:9
- Instagram: 1080x1080 (square) or 1080x1920 (story)
- TikTok: 1080x1920 (vertical)

================================================================================
NEED HELP?
================================================================================

- Check scene_order.json for scene descriptions
- Keep Media folder in same location as draft_content.json
- If clips don't load, check file paths in draft_content.json

Generated: 2026-02-12 18:44:50
================================================================================
